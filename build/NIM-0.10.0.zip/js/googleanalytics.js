var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-87646107-1']);
_gaq.push(['_trackPageview']);
_gaq.push(['_setCampSourceKey', 'com.june07']);
_gaq.push(['_setCampMediumKey', 'nim']);

(function () {
    var ga = document.createElement('script');
    ga.type = 'text/javascript';
    ga.async = true;
    ga.src = 'https://ssl.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ga, s);
})();
