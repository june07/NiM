var config = {
	yandexAPIKey: 'trnsl.1.1.20161130T163110Z.e84376d2de6447a2.4abeda91a929fa66b21fb232e580ba96684e77d9'
}

module.exports = config;