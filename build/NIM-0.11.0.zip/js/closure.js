goog.provide('nim.closure');

goog.require('goog.crypt');
goog.require('goog.crypt.Md5');

goog.exportSymbol('nim.closure', nim.closure);