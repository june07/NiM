module.exports = function (hook) {
  hook.res.write(JSON.stringify(hook.params, true, 2));
  console.log("Hello World");
  hook.res.end('');
};
//oauth="+GITHUB_OAUTH+"hmac="+hmac